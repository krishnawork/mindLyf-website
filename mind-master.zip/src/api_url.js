import React, { Component } from 'react';

// var base_url = "http://mindlyftest.antimtechnologies.com:8001/api/"
var base_url = "http://mindlyftestadmin.antimtechnologies.com:8001/api/"
// var base_url = "http://mindlyftest.antimtechnologies.com:8000/api/"
// var base_url = "http://localhost:8080/api/"

export default base_url;
